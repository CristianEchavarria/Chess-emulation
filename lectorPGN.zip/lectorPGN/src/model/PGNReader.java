package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PGNReader {
    public static List<String> loadMoves(String filePath) throws IOException {
        List<String> moves = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.startsWith("[") && !line.isEmpty()) {
                    String[] tokens = line.split("\\s+");
                    for (String token : tokens) {
                        if (!token.matches("\\d+\\.")) { // Ignore move numbers
                            moves.add(token);
                        }
                    }
                }
            }
        }
        return moves;
    }
}

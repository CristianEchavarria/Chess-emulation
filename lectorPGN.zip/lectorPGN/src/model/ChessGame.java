package model;

import java.util.List;

public class ChessGame {
    private List<String> moves;
    private int currentMoveIndex;

    public ChessGame(List<String> moves) {
        this.moves = moves;
        this.currentMoveIndex = -1; // No move selected initially
    }

    public String getNextMove() {
        if (currentMoveIndex < moves.size() - 1) {
            currentMoveIndex++;
            return moves.get(currentMoveIndex);
        }
        return null; // No more moves
    }

    public String getPreviousMove() {
        if (currentMoveIndex > 0) {
            currentMoveIndex--;
            return moves.get(currentMoveIndex);
        }
        return null; // No previous moves
    }

    public void resetGame() {
        currentMoveIndex = -1;
    }

    public int getTotalMoves() {
        return moves.size();
    }
}

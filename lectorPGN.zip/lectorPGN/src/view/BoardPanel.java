package view;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class BoardPanel extends JPanel {
    private static final int TILE_SIZE = 72; // Tamaño de cada casilla
    private static final int BOARD_SIZE = 8; // Tamaño del tablero (8x8)
    private String[][] boardState; // Estado del tablero
    private Map<String, ImageIcon> pieceImages; // Imágenes de las piezas

    public BoardPanel() {
        setPreferredSize(new Dimension(TILE_SIZE * BOARD_SIZE, TILE_SIZE * BOARD_SIZE));
        setBackground(Color.LIGHT_GRAY);
        loadPieceImages();
        initializeBoard();
    }

    // Carga las imágenes de las piezas desde el paquete resources
    private void loadPieceImages() {
        pieceImages = new HashMap<>();
        String[] pieces = {
                "king", "queen", "rook", "bishop", "knight", "pawn"
        };
        String[] colors = {"white", "black"};

        for (String piece : pieces) {
            for (String color : colors) {
                String key = piece + "_" + color;
                pieceImages.put(key, new ImageIcon(getClass().getResource("/resources/" + key + ".png")));
            }
        }
    }

    private void initializeBoard() {
        boardState = new String[8][8];

        // Piezas negras
        boardState[0][0] = "rook_black";
        boardState[0][1] = "knight_black";
        boardState[0][2] = "bishop_black";
        boardState[0][3] = "queen_black";
        boardState[0][4] = "king_black";
        boardState[0][5] = "bishop_black";
        boardState[0][6] = "knight_black";
        boardState[0][7] = "rook_black";
        for (int i = 0; i < 8; i++) {
            boardState[1][i] = "pawn_black";
        }

        // Piezas blancas
        boardState[7][0] = "rook_white";
        boardState[7][1] = "knight_white";
        boardState[7][2] = "bishop_white";
        boardState[7][3] = "queen_white";
        boardState[7][4] = "king_white";
        boardState[7][5] = "bishop_white";
        boardState[7][6] = "knight_white";
        boardState[7][7] = "rook_white";
        for (int i = 0; i < 8; i++) {
            boardState[6][i] = "pawn_white";
        }

        // Casillas vacías
        for (int i = 2; i < 6; i++) {
            for (int j = 0; j < 8; j++) {
                boardState[i][j] = null;
            }
        }
    }


    public void updateBoard(String move) {
        if (move == null || move.isEmpty()) return;

        try {
            // Ignorar resultado de la partida (1-0, 0-1, 1/2-1/2)
            if (move.matches("\\d-\\d|1/2-1/2")) return;

            // Enroque
            if (move.equals("O-O")) { // Enroque corto
                int row = boardState[7][4] != null && boardState[7][4].contains("king_white") ? 7 : 0; // Blanca o negra
                boardState[row][6] = boardState[row][4]; // Mueve el rey
                boardState[row][5] = boardState[row][7]; // Mueve la torre
                boardState[row][4] = null;
                boardState[row][7] = null;
            } else if (move.equals("O-O-O")) { // Enroque largo
                int row = boardState[7][4] != null && boardState[7][4].contains("king_white") ? 7 : 0; // Blanca o negra
                boardState[row][2] = boardState[row][4]; // Mueve el rey
                boardState[row][3] = boardState[row][0]; // Mueve la torre
                boardState[row][4] = null;
                boardState[row][0] = null;
            } else {
                // Movimientos estándar en notación algebraica
                interpretAlgebraicMove(move);
            }

            // Redibuja el tablero
            repaint();
        } catch (Exception e) {
            System.err.println("Movimiento inválido: " + move);
        }
    }

    private void interpretAlgebraicMove(String move) {
        String piece = "pawn"; // Por defecto, asume peón
        int specifiedCol = -1; // Columna especificada, si aplica

        // Identificar la pieza
        if (Character.isUpperCase(move.charAt(0))) {
            piece = switch (move.charAt(0)) {
                case 'N' -> "knight";
                case 'B' -> "bishop";
                case 'R' -> "rook";
                case 'Q' -> "queen";
                case 'K' -> "king";
                default -> throw new IllegalArgumentException("Pieza desconocida: " + move);
            };
            move = move.substring(1); // Eliminar el prefijo de la pieza
        }

        // Verificar si especifica columna o fila (como en "Nbd7")
        if (move.length() > 2 && Character.isLetter(move.charAt(0))) {
            specifiedCol = move.charAt(0) - 'a';
            move = move.substring(1); // Eliminar columna especificada
        }

        // Coordenadas de destino
        int targetCol = move.charAt(move.length() - 2) - 'a';
        int targetRow = 8 - Character.getNumericValue(move.charAt(move.length() - 1));

        // Buscar la pieza origen
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                String boardPiece = boardState[row][col];
                if (boardPiece != null && boardPiece.contains(piece)) {
                    if (specifiedCol != -1 && col != specifiedCol) continue; // Verificar columna especificada

                    // Validar si la pieza puede llegar al destino
                    if (isValidMove(piece, row, col, targetRow, targetCol, move.contains("x"))) {
                        boardState[targetRow][targetCol] = boardPiece;
                        boardState[row][col] = null;
                        return;
                    }
                }
            }
        }

        throw new IllegalArgumentException("No se encontró una pieza válida para el movimiento: " + move);
    }


    private boolean isValidMove(String piece, int startRow, int startCol, int endRow, int endCol, boolean isCapture) {
        switch (piece) {
            case "pawn":
                int direction = boardState[startRow][startCol].contains("white") ? -1 : 1;
                if (isCapture) {
                    return Math.abs(startCol - endCol) == 1 && endRow - startRow == direction;
                } else {
                    return startCol == endCol && (endRow - startRow == direction || // Movimiento normal
                            (startRow == (direction == -1 ? 6 : 1) && endRow - startRow == 2 * direction)); // Avance doble
                }
            case "knight":
                return Math.abs(startRow - endRow) * Math.abs(startCol - endCol) == 2;
            case "bishop":
                return Math.abs(startRow - endRow) == Math.abs(startCol - endCol);
            case "rook":
                return startRow == endRow || startCol == endCol;
            case "queen":
                return isValidMove("rook", startRow, startCol, endRow, endCol, isCapture) ||
                        isValidMove("bishop", startRow, startCol, endRow, endCol, isCapture);
            case "king":
                return Math.abs(startRow - endRow) <= 1 && Math.abs(startCol - endCol) <= 1;
        }
        return false;
    }

    public void resetBoard() {
        initializeBoard();
        repaint();
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Dibuja el tablero
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                boolean isLightTile = (row + col) % 2 == 0;
                g.setColor(isLightTile ? Color.WHITE : Color.GRAY);
                g.fillRect(col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE);

                // Dibuja la pieza si existe
                String piece = boardState[row][col];
                if (piece != null) {
                    ImageIcon icon = pieceImages.get(piece);
                    if (icon != null) {
                        g.drawImage(icon.getImage(), col * TILE_SIZE, row * TILE_SIZE, TILE_SIZE, TILE_SIZE, this);
                    }
                }
            }
        }
    }
}

package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class ChessView extends JFrame {
    private JButton loadButton, nextButton, prevButton;
    private JLabel moveLabel, totalMovesLabel;
    private BoardPanel boardPanel;
    private JButton resetButton;

    public ChessView() {
        setTitle("Chess Game Viewer");
        setSize(592, 651);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear el panel de control antes de usarlo
        JPanel controlPanel = new JPanel();

        // Crear y agregar el botón de reinicio
        resetButton = new JButton("Reset");
        controlPanel.add(resetButton);

        // Crear el panel del tablero
        boardPanel = new BoardPanel();
        add(boardPanel, BorderLayout.CENTER);

        // Crear y agregar otros botones y etiquetas
        loadButton = new JButton("Load PGN");
        nextButton = new JButton("Next Move");
        prevButton = new JButton("Previous Move");
        moveLabel = new JLabel("Current Move: ");
        totalMovesLabel = new JLabel("Total Moves: 0");

        controlPanel.add(loadButton);
        controlPanel.add(prevButton);
        controlPanel.add(nextButton);
        controlPanel.add(moveLabel);
        controlPanel.add(totalMovesLabel);

        // Agregar el panel de control al sur de la ventana
        add(controlPanel, BorderLayout.SOUTH);
    }

    public void setMoveLabel(String move) {
        moveLabel.setText("Current Move: " + move);
    }

    public void setTotalMovesLabel(int totalMoves) {
        totalMovesLabel.setText("Total Moves: " + totalMoves);
    }

    public void addLoadButtonListener(ActionListener listener) {
        loadButton.addActionListener(listener);
    }

    public void addNextButtonListener(ActionListener listener) {
        nextButton.addActionListener(listener);
    }

    public void addPrevButtonListener(ActionListener listener) {
        prevButton.addActionListener(listener);
    }

    public BoardPanel getBoardPanel() {
        return boardPanel;
    }
    public void addResetButtonListener(ActionListener listener) {
        resetButton.addActionListener(listener);
    }
}

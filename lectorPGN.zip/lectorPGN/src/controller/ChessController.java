package controller;

import model.ChessGame;
import model.PGNReader;
import view.ChessView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ChessController {
    private ChessGame chessGame;
    private ChessView chessView;

    public ChessController(ChessView chessView) {
        this.chessView = chessView;
        initController();
    }

    private void initController() {
        // Listener para cargar un archivo PGN
        chessView.addLoadButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                if (fileChooser.showOpenDialog(chessView) == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    try {
                        chessGame = new ChessGame(PGNReader.loadMoves(file.getAbsolutePath()));
                        resetGame(); // Reinicia el tablero y el estado
                        chessView.setTotalMovesLabel(chessGame.getTotalMoves());
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(chessView, "Error loading file: " + ex.getMessage());
                    }
                }
            }
        });

        // Listener para avanzar al siguiente movimiento
        chessView.addNextButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chessGame != null) {
                    String move = chessGame.getNextMove();
                    if (move != null) {
                        chessView.setMoveLabel(move);
                        chessView.getBoardPanel().updateBoard(move);
                    }
                }
            }
        });

        // Listener para retroceder al movimiento anterior
        chessView.addPrevButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chessGame != null) {
                    String move = chessGame.getPreviousMove();
                    if (move != null) {
                        chessView.setMoveLabel(move);
                        chessView.getBoardPanel().updateBoard(move);
                    }
                }
            }
        });

        // Listener para el botón "Reiniciar"
        chessView.addResetButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetGame(); // Llama al método para reiniciar el juego
            }
        });
    }

    // Método para reiniciar el juego y el tablero
    private void resetGame() {
        chessView.getBoardPanel().resetBoard(); // Reinicia el tablero a su estado inicial
        chessView.setMoveLabel(""); // Limpia el texto del movimiento actual
        chessView.setTotalMovesLabel(0); // Reinicia el conteo de movimientos totales
        if (chessGame != null) {
            chessGame.resetGame(); // Resetea el estado interno del juego (si es necesario)
        }
    }
}

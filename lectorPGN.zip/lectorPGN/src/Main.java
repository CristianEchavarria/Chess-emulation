import controller.ChessController;
import view.ChessView;

public class Main {
    public static void main(String[] args) {
        ChessView chessView = new ChessView();
        new ChessController(chessView);
        chessView.setVisible(true);
    }
}
